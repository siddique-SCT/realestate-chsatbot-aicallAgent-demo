const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const axios = require('axios');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Demo listings
const listings = [
  {id:1, title:'3-bed house Clifton', description:'Beautiful 3 bed, 2 bath house in Clifton with sea view', price:250000, location:'Clifton', bedrooms:3},
  {id:2, title:'2-bed flat DHA', description:'2 bed flat near park in DHA', price:120000, location:'DHA', bedrooms:2},
  {id:3, title:'3-bed apartment PECHS', description:'Spacious 3 bed apartment in PECHS', price:180000, location:'PECHS', bedrooms:3}
];

// Simple keyword-based retrieval for demo (replace with FAISS + embeddings in production)
app.post('/api/chat', async (req, res) => {
  const { message } = req.body;
  if(!message) return res.json({reply: "Please send a message."});
  const q = message.toLowerCase();
  const matches = listings.filter(l => q.includes(l.location.toLowerCase()) || q.includes(String(l.bedrooms)));
  let reply;
  if(matches.length) {
    reply = `I found ${matches.length} listing(s). Example: ${matches[0].title} — ${matches[0].description} (Price: ${matches[0].price})`;
  } else {
    reply = "Sorry, I couldn't find matching listings. Try: '3 bed Clifton' or mention an area.";
  }
  res.json({reply});
});

// Save lead (demo: just print to console and optionally trigger callback webhook)
app.post('/api/lead', async (req, res) => {
  const { name, phone, email, consent } = req.body;
  console.log('New lead:', { name, phone, email, consent, time: new Date().toISOString() });
  // TODO: persist to DB, encrypt phone if storing long-term
  // Example: trigger callback provider webhook here (Brightcall/Twilio)
  // await axios.post('https://your-callback-service', { name, phone, email });
  res.json({ status: 'lead saved (demo)' });
});

// Example callback trigger endpoint (stub)
app.post('/api/callback', async (req, res) => {
  const { provider='twilio', phone } = req.body;
  // Implement Twilio/Brightcall integration here
  console.log('Callback requested', { provider, phone });
  res.json({ status: 'callback queued (demo)', provider, phone });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Backend demo server running on port ${PORT}`));
