# embed_index.py
# Demo script to create embeddings and index with FAISS.
# Requires: pip install sentence-transformers faiss-cpu numpy

from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import json

model = SentenceTransformer('all-MiniLM-L6-v2')  # small & fast
with open('listings.json') as f:
    listings = json.load(f)

texts = [l['description'] for l in listings]
embs = model.encode(texts, convert_to_numpy=True)
d = embs.shape[1]
index = faiss.IndexFlatL2(d)
index.add(embs)
faiss.write_index(index, 'listings.index')
with open('id_map.json', 'w') as f:
    json.dump([l['id'] for l in listings], f)
print('Indexed', len(listings))
