import { useState } from 'react';

export default function ChatWidget() {
  const [open,setOpen] = useState(false);
  const [messages,setMessages] = useState([{from:'bot', text:'Hi! I can help you find properties. Try saying: "3 bed in Clifton"'}]);
  const [text,setText] = useState('');
  const [lead, setLead] = useState({name:'',phone:'',email:'',consent:false});

  async function sendMessage() {
    if(!text) return;
    const userMsg = {from:'user', text};
    setMessages(m=>[...m,userMsg]);
    setText('');
    const res = await fetch('/api/chat', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({message: text})
    });
    const data = await res.json();
    setMessages(m=>[...m,{from:'bot', text: data.reply}]);
  }

  async function submitLead() {
    const res = await fetch('/api/lead', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(lead)
    });
    const result = await res.json();
    alert(result.status || 'lead saved');
  }

  return (
    <div style={{position:'fixed', right:20, bottom:20, width:360, zIndex:9999}}>
      <button onClick={()=>setOpen(!open)} style={{padding:10}}>Chat</button>
      {open && (
        <div style={{border:'1px solid #ccc', background:'#fff', padding:12, borderRadius:8, boxShadow:'0 4px 12px rgba(0,0,0,0.1)'}}>
          <div style={{height:260, overflow:'auto', marginBottom:8}}>
            {messages.map((m,i)=> <div key={i} style={{margin:6}}><b>{m.from}:</b> {m.text}</div>)}
          </div>
          <div style={{display:'flex', gap:6}}>
            <input value={text} onChange={e=>setText(e.target.value)} placeholder="Type message..." style={{flex:1}} />
            <button onClick={sendMessage}>Send</button>
          </div>

          <hr/>
          <h4 style={{margin:'8px 0'}}>Request Callback</h4>
          <input placeholder="Name" value={lead.name} onChange={e=>setLead({...lead,name:e.target.value})} style={{width:'100%',marginBottom:6}}/>
          <input placeholder="Phone" value={lead.phone} onChange={e=>setLead({...lead,phone:e.target.value})} style={{width:'100%',marginBottom:6}}/>
          <input placeholder="Email" value={lead.email} onChange={e=>setLead({...lead,email:e.target.value})} style={{width:'100%',marginBottom:6}}/>
          <label style={{display:'block', marginBottom:6}}><input type="checkbox" checked={lead.consent} onChange={e=>setLead({...lead,consent:e.target.checked})}/> I consent to be contacted.</label>
          <button onClick={submitLead} style={{width:'100%'}}>Request Callback</button>
        </div>
      )}
    </div>
  );
}
